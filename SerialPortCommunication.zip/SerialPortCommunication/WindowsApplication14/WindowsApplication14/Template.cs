﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace WindowsApplication14
{
    public class Template
    {
        public string Header { get; set; }
        public string Data { get; set; }
        public string Footer { get; set; }

    }
}
